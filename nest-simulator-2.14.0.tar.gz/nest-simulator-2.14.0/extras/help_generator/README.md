# README for the NEST help generator

The parser goes through all .sli and .cc files to find documentation
and converts it into .html and .hlp files.