# Introduction to PyNEST

-   [Part 1: Neurons and simple neural networks](part-1-neurons-and-simple-neural-networks.md)
-   [Part 2: Populations of neurons](part-2-populations-of-neurons.md)
-   [Part 3: Connecting networks with synapses](part-3-connecting-networks-with-synapses.md)
-   [Part 4: Topologically structured networks](part-4-topologically-structured-networks.md)
