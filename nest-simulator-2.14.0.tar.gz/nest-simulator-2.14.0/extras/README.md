# `extras` folder

This directory contains several helper scripts for running NEST in a distributed setup (`nest_serial` and `nest_indirect`), some patches that are used during the installation process on different architectures, and the SLI mode for emacs.
