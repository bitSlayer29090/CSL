?package(nest):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="nest" command="/usr/bin/nest"
