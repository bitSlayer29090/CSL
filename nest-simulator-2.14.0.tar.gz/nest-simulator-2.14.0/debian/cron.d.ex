#
# Regular cron jobs for the nest package
#
0 4	* * *	root	nest_maintenance
