#!/usr/bin/env sh

x=`$1`
exit $?
