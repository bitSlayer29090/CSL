#include <cmath>

int main(int argc, char const *argv[])
{
  double x = nan(0);
  return 0;
}
