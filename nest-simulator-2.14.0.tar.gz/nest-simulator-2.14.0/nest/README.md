# `nest` folder

This directory contains the code to build the nest executable. Basically main.cpp just collects all necessary objects and links the executable against the necessary libraries.
